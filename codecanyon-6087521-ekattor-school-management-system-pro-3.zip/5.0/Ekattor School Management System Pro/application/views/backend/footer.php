<!-- Footer -->
<footer class="main">
	&copy; 2017 <strong>Ekattor School Manager | Version 5.0</strong>.
    Developed by
	<a href="http://creativeitem.com"
    	target="_blank">Creativeitem</a>
</footer>
